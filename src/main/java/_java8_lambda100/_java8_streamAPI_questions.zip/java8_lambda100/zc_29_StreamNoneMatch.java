package java8_lambda100;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
public class zc_29_StreamNoneMatch {
    public static void main(String[] args) {
    }
}
