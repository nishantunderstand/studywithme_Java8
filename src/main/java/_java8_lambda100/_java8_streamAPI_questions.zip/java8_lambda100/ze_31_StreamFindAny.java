package java8_lambda100;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
public class ze_31_StreamFindAny {
    public static void main(String[] args) {
    }
}
